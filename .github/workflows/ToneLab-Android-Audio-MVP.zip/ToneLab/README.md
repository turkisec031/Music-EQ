# ToneLab Equalizer — Android audio-effects MVP (0.2.0)

Native Kotlin + Jetpack Compose app with: 
- Local audio file picker and in-app playback via AndroidX Media3 ExoPlayer
- Android `Equalizer`, `BassBoost`, and `Virtualizer` effects attached to ToneLab playback session
- Displays the actual equalizer bands reported by the device (up to 31 shown)
- Adjustable band levels, bass boost, virtualizer and enable/bypass
- Four selectable skins; preferences saved locally

## Build
1. Install current Android Studio.
2. Open the `ToneLab` folder and allow Gradle sync.
3. Use SDK 35 if prompted.
4. Run on a physical Android device for meaningful audio-effect testing. Emulators may not implement effects.

## Important limitations
- Android's built-in Equalizer chooses its own band count and frequency centers. The app cannot force that system effect to expose 31 independently adjustable bands. This UI shows the real bands supplied by the phone. A true consistent 31-band EQ requires custom PCM DSP in the in-app audio pipeline, which is a separate implementation step.
- BassBoost/Virtualizer availability and quality vary by manufacturer and audio route.
- This build processes ToneLab's own playback session. It cannot universally process audio from every other app. Another app must expose/attach a compatible audio session or support Android's audio-effects control-panel contract; Android restrictions and vendor audio stacks apply.
- External-app integration is not equivalent to unrestricted system-wide processing.
- Source project has not been built or tested on a physical device in this environment.
