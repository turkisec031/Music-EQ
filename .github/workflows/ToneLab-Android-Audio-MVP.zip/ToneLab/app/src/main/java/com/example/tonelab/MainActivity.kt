package com.example.tonelab

import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.util.Locale

private data class Skin(val name: String, val bg: Color, val panel: Color, val accent: Color, val text: Color)
private val skins = listOf(
    Skin("Neon Blue", Color(0xFF080D18), Color(0xFF111B2B), Color(0xFF31D7FF), Color(0xFFF2F7FF)),
    Skin("Violet", Color(0xFF100A1B), Color(0xFF211431), Color(0xFFCA7DFF), Color(0xFFFFF5FF)),
    Skin("AMOLED", Color.Black, Color(0xFF101010), Color(0xFF55F2A5), Color.White),
    Skin("Sunset", Color(0xFF1B0D0B), Color(0xFF321713), Color(0xFFFF9A54), Color(0xFFFFF3E9))
)
private val frequencies = listOf(20,25,31,40,50,63,80,100,125,160,200,250,315,400,500,630,800,1000,1250,1600,2000,2500,3150,4000,5000,6300,8000,10000,12500,16000,20000)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var audioSessionId: Int = 0
    private var effectError: String? = null
    private var uiStatus by mutableStateOf("Choose a local audio file to test real audio effects.")
    private var uiTrackName by mutableStateOf("No track selected")
    private var uiPlayerReady by mutableStateOf(false)
    private var uiPlaying by mutableStateOf(false)

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            playUri(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val prefs = getSharedPreferences("tonelab_v2", MODE_PRIVATE)
            var skinIndex by remember { mutableIntStateOf(prefs.getInt("skin", 0).coerceIn(skins.indices)) }
            var enabled by remember { mutableStateOf(prefs.getBoolean("enabled", true)) }
            var bassLevel by remember { mutableIntStateOf(prefs.getInt("bass", 500).coerceIn(0, 1000)) }
            var virtualLevel by remember { mutableIntStateOf(prefs.getInt("virtual", 350).coerceIn(0, 1000)) }
            var bandCount by remember { mutableIntStateOf(0) }
            var bandLabels by remember { mutableStateOf(listOf<String>()) }
            var bandValues by remember { mutableStateOf(listOf<Float>()) }
            val skin = skins[skinIndex]

            fun persist() { prefs.edit().putInt("skin", skinIndex).putBoolean("enabled", enabled).putInt("bass", bassLevel).putInt("virtual", virtualLevel).apply() }
            fun refreshBands() {
                val eq = equalizer
                if (eq == null) { bandCount = 0; bandLabels = emptyList(); bandValues = emptyList(); return }
                val n = eq.numberOfBands.toInt().coerceAtMost(31)
                bandCount = n
                bandLabels = (0 until n).map { i ->
                    val hz = eq.getCenterFreq(i.toShort()) / 1000f
                    if (hz >= 1000f) String.format(Locale.US, "%.1f kHz", hz / 1000f) else "${hz.toInt()} Hz"
                }
                val range = eq.bandLevelRange
                bandValues = (0 until n).map { i -> eq.getBandLevel(i.toShort()).toFloat() / 100f }
            }
            MaterialTheme(colorScheme = darkColorScheme(primary = skin.accent, background = skin.bg, surface = skin.panel, onSurface = skin.text)) {
                Column(Modifier.fillMaxSize().background(skin.bg).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("TONE LAB", color = skin.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                            Text("31-band Equalizer", color = skin.text, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Switch(checked = enabled, onCheckedChange = { v -> enabled = v; equalizer?.enabled = v; bassBoost?.enabled = v; virtualizer?.enabled = v; persist() })
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = skin.panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("IN-APP PLAYER", color = skin.accent, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                            Text(uiTrackName, color = skin.text, fontWeight = FontWeight.SemiBold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Button(onClick = { pickAudio.launch(arrayOf("audio/*")) }) { Text("Choose audio") }
                                OutlinedButton(onClick = {
                                    val p = player
                                    if (p != null) { if (p.isPlaying) { p.pause(); uiPlaying = false } else { p.play(); uiPlaying = true } }
                                }, enabled = uiPlayerReady) { Text(if (uiPlaying) "Pause" else "Play") }
                                OutlinedButton(onClick = { player?.stop(); uiPlaying = false }) { Text("Stop") }
                            }
                            Text(uiStatus, color = skin.text.copy(alpha = .7f), fontSize = 12.sp, lineHeight = 17.sp)
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = skin.panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("DEVICE AUDIO BANDS", color = skin.text, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
                                Text(if (bandCount > 0) "$bandCount bands available" else "Awaiting player", color = skin.accent, fontSize = 11.sp)
                            }
                            if (bandCount == 0) Text("Select and play a track first. Android reports the number of real equalizer bands supported by this device; it may be fewer than 31.", color = skin.text.copy(alpha = .7f), fontSize = 12.sp, lineHeight = 17.sp)
                            else {
                                bandLabels.forEachIndexed { i, label ->
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(label, modifier = Modifier.width(58.dp), color = skin.text, fontSize = 11.sp)
                                        Slider(value = bandValues.getOrElse(i) { 0f }, onValueChange = { v ->
                                            val eq = equalizer ?: return@Slider
                                            try {
                                                val range = eq.bandLevelRange
                                                val level = (v * 100).toInt().coerceIn(range[0].toInt(), range[1].toInt())
                                                eq.setBandLevel(i.toShort(), level.toShort())
                                                bandValues = bandValues.toMutableList().also { it[i] = level / 100f }
                                            } catch (_: Exception) { }
                                        }, valueRange = -15f..15f, enabled = enabled, colors = SliderDefaults.colors(thumbColor = skin.accent, activeTrackColor = skin.accent, inactiveTrackColor = skin.text.copy(alpha = .18f)), modifier = Modifier.weight(1f))
                                        Text("${bandValues.getOrElse(i) { 0f }.toInt()} dB", color = skin.accent, fontSize = 10.sp, modifier = Modifier.width(38.dp), textAlign = TextAlign.End)
                                    }
                                }
                            }
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = skin.panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("ENHANCEMENTS", color = skin.text, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text("Bass boost  ·  ${bassLevel / 10}%", color = skin.text, fontSize = 12.sp)
                            Slider(value = bassLevel.toFloat(), onValueChange = { bassLevel = it.toInt(); try { bassBoost?.setStrength(bassLevel.toShort()) } catch (_: Exception) {}; persist() }, valueRange = 0f..1000f, enabled = enabled, colors = SliderDefaults.colors(thumbColor = skin.accent, activeTrackColor = skin.accent))
                            Text("Virtualizer  ·  ${virtualLevel / 10}%", color = skin.text, fontSize = 12.sp)
                            Slider(value = virtualLevel.toFloat(), onValueChange = { virtualLevel = it.toInt(); try { virtualizer?.setStrength(virtualLevel.toShort()) } catch (_: Exception) {}; persist() }, valueRange = 0f..1000f, enabled = enabled, colors = SliderDefaults.colors(thumbColor = skin.accent, activeTrackColor = skin.accent))
                            Text("Enhancement availability and effect strength are device-dependent.", color = skin.text.copy(alpha = .6f), fontSize = 11.sp)
                        }
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("SKINS", color = skin.text, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            skins.forEachIndexed { index, item ->
                                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Surface(onClick = { skinIndex = index; persist() }, shape = CircleShape, color = item.bg, modifier = Modifier.size(42.dp).then(if (skinIndex == index) Modifier.border(3.dp, item.accent, CircleShape) else Modifier.border(1.dp, item.accent.copy(alpha = .45f), CircleShape))) { Box(contentAlignment = Alignment.Center) { Box(Modifier.size(12.dp).background(item.accent, CircleShape)) } }
                                    Text(item.name, color = skin.text.copy(alpha = .8f), fontSize = 9.sp, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = skin.panel), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("IMPORTANT COMPATIBILITY NOTE", color = skin.accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text("This build applies Android's real Equalizer, BassBoost and Virtualizer to ToneLab's own player session. Android's built-in Equalizer exposes a device-defined band count, so a true 31 independently adjustable-band DSP is not guaranteed on every phone. Other music apps must expose/attach a compatible audio session or open an audio-effects panel; Android does not let an ordinary app universally process all other apps' audio.", color = skin.text.copy(alpha = .75f), fontSize = 12.sp, lineHeight = 17.sp)
                        }
                    }
                    Text("TONE LAB  •  VERSION 0.2.0 · AUDIO EFFECTS", modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp), color = skin.text.copy(alpha = .35f), fontSize = 10.sp, textAlign = TextAlign.Center, letterSpacing = 1.sp)
                }
            }
        }
    }

    private fun playUri(uri: Uri) {
        try {
            if (player == null) {
                player = ExoPlayer.Builder(this).build().also { p ->
                    p.addListener(object : Player.Listener {
                        override fun onIsPlayingChanged(isPlaying: Boolean) { uiPlaying = isPlaying }
                        override fun onPlayerError(error: PlaybackException) { runOnUiThread { /* surfaced on next launch/status */ } }
                    })
                }
            }
            val p = player!!
            p.setMediaItem(MediaItem.fromUri(uri))
            p.prepare()
            p.playWhenReady = true
            p.addListener(object : Player.Listener { override fun onPlaybackStateChanged(playbackState: Int) { if (playbackState == Player.STATE_READY && p.audioSessionId != 0) attachEffectsForSession(p.audioSessionId) } })
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected audio"
            setTrackLabel(name)
            if (p.audioSessionId != 0) attachEffectsForSession(p.audioSessionId)
        } catch (e: Exception) { setStatus("Could not play this file: ${e.message ?: "unsupported format"}") }
    }

    private fun attachEffectsForSession(sessionId: Int) {
        runOnUiThread {
            releaseEffects()
            try {
                equalizer = Equalizer(0, sessionId).apply { enabled = true }
                bassBoost = BassBoost(0, sessionId).apply { setStrength(500.toShort()); enabled = true }
                virtualizer = Virtualizer(0, sessionId).apply { setStrength(350.toShort()); enabled = true }
                setStatus("Android audio effects attached to playback session $sessionId.")
                setPlayerReady(true)
                // Broadcast the standard effect-control session contract for compatible host apps.
                sendBroadcast(Intent(android.media.audiofx.AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION).apply {
                    putExtra(android.media.audiofx.AudioEffect.EXTRA_AUDIO_SESSION, sessionId)
                    putExtra(android.media.audiofx.AudioEffect.EXTRA_PACKAGE_NAME, packageName)
                })
            } catch (e: Exception) {
                setStatus("Audio effects unavailable on this device: ${e.message ?: "unsupported"}")
                setPlayerReady(false)
            }
        }
    }

    private fun releaseEffects() {
        try { equalizer?.release() } catch (_: Exception) {}; equalizer = null
        try { bassBoost?.release() } catch (_: Exception) {}; bassBoost = null
        try { virtualizer?.release() } catch (_: Exception) {}; virtualizer = null
    }

    private fun setStatus(message: String) { uiStatus = message; android.util.Log.i("ToneLab", message) }
    private fun setTrackLabel(name: String) { uiTrackName = name; android.util.Log.i("ToneLab", "Selected: $name") }
    private fun setPlayerReady(ready: Boolean) { uiPlayerReady = ready; android.util.Log.i("ToneLab", "Player ready: $ready") }

    override fun onDestroy() {
        releaseEffects()
        player?.release(); player = null
        super.onDestroy()
    }
}
